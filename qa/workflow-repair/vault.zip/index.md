# ai客服

从已发布片段生成；原件链接需在中台登录后访问。

- [P1_信誉分规则.docx](documents/af24aad44d937cf64c107f1d54bd6a17a78fe5c5ef83f30b4223776a32c92dc2.md)
- [P2_违规处罚标准_公开版_结构化.md](documents/208bc9bf6fd188f46d88ba4ad64d167bcb5a5e0eb4b74bad3289a05722f7f387.md)
- [P3_举报与申诉流程.docx](documents/bc1f3033bc75278097bd7a94ff774ee69e8a565968355b929e5ce9a0e939f738.md)