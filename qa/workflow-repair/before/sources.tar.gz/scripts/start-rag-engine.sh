#!/bin/sh
set -eu
PROJECT_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$PROJECT_ROOT"
exec integrations/knowledge-rag-venv/bin/python integrations/knowledge_bridge.py
